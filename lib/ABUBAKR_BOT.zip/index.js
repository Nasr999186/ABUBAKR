
// بوت واتساب بسيط - إعداد ABUBAKR SUD
const { default: makeWASocket, useSingleFileAuthState } = require('@whiskeysockets/baileys');
const { Boom } = require('@hapi/boom');
const fs = require('fs');
const { state, saveState } = useSingleFileAuthState('./auth_info.json');

async function startBot() {
    const sock = makeWASocket({
        auth: state,
        printQRInTerminal: true,
    });

    sock.ev.on('creds.update', saveState);

    sock.ev.on('messages.upsert', async ({ messages, type }) => {
        const msg = messages[0];
        if (!msg.message) return;

        const text = msg.message.conversation || msg.message.extendedTextMessage?.text;

        if (text === '.ping') {
            await sock.sendMessage(msg.key.remoteJid, { text: 'بوت شغال تمام يا ABUBAKR SUD!' });
        }

        if (text === '.اوامر') {
            await sock.sendMessage(msg.key.remoteJid, { text: 'الأوامر:
.ping
.اوامر
.ملصق
.حذف
والمزيد قريباً!' });
        }
    });
}

startBot();
